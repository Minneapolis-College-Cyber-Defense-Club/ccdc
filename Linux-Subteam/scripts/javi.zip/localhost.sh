#!/bin/bash

cp localhost.cfg localhost.cfg.backup
rm -f localhost.cfg



# Create the file
sudo touch /usr/local/nagios/etc/objects/localhost.cfg

# Define the file contents
cat <<EOT | sudo tee /usr/local/nagios/etc/objects/localhost.cfg
define host{
        use                     linux-server
        host_name               nagios_server
        alias                   linux centos
        address                 127.0.0.1
}
define host{
        use                     linux-server
        host_name               centos8
        alias                   linux centos
        address                 192.168.22.42
}
define host{
        use                     linux-server
        host_name               onion
        alias                   linux centos
        address                 192.168.22.193
}

define host{
        use                     linux-server
        host_name               centos3
        alias                   linux centos
        address                 192.168.22.239
}
define host{
        use                     linux-server
        host_name               centos5
        alias                   linux centos
        address                 192.168.22.62
}
define host{
        use                     linux-server
        host_name               centos6
        alias                   linux centos
        address                 192.168.22.62
}
define host{
        use                     linux-server
        host_name               centos7
        alias                   linux centos
        address                 192.168.22.62
}
define host{
        use                     linux-server
        host_name               centos10
        alias                   linux centos
        address                 192.168.22.62
}


define host{
        use                     linux-server
        host_name               centos9
        alias                   linux centos
        address                 192.168.22.239
}



####### host troups

define hostgroup{
        hostgroup_name          servidores_linux
        alias                   servidores_linux
        members                 nagios_server
}


### servicios

define service{
        use                     generic-service
        hostgroup_name          servidores_linux
        service_description     Uptime
        check_command           check_nrpe!check_uptime
}


define service{
        use                     generic-service
        hostgroup_name          servidores_linux
        service_description     Current Load
        check_command           check_nrpe!check_load
}

define service{
        use                     generic-service
        hostgroup_name          servidores_linux
        service_description     Ping
        check_command           check_nrpe!check_load!500.0,20%!800.0,60%

}

define service{
        use                     generic-service
        hostgroup_name          servidores_linux
        service_description     Users actives
        check_command           check_nrpe!check_users
}


define service{
        use                     generic-service
        hostgroup_name          servidores_linux
        service_description     port 22
        check_command           check_tcp!22
}
define service{
        use                     generic-service
        hostgroup_name          servidores_linux
        service_description     port 443
        check_command           check_tcp!443
}
define service{
        use                     generic-service
        hostgroup_name          servidores_linux
        service_description     port 80
        check_command           check_tcp!80
#        host_name               !cliente
}
EOT

echo "File created successfully!"
