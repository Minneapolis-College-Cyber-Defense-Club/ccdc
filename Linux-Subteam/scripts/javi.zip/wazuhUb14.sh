#!/bin/bash

apt-get install gnupg apt-transport-https
curl -s https://packages.wazuh.com/key/GPG-KEY-WAZUH | apt-key add -
echo "deb https://packages.wazuh.com/4.x/apt/ stable main" | tee -a /etc/apt/sources.list.d/wazuh.list
apt-get update
WAZUH_MANAGER="192.168.22.120" apt-get install wazuh-agent

service wazuh-agent enable
service wazuh-agent start

#systemctl enable wazuh-agent.service

echo "alias wass='service wazuh-agent status'" >> ~/.bashrc
echo "alias wasr='service wazuh-agent restart'" >> ~/.bashrc 
echo "alias wast='tail -f /var/ossec/logs/ossec.log'" >> ~/.bashrc 
echo "alias wasf='sudo nano /var/ossec/etc/ossec.conf'" >> ~/.bashrc

sudo firewall-cmd --add-port=1514/tcp --permanent
sudo firewall-cmd --add-port=1514/udp --permanent
sudo firewall-cmd --add-port=1515/tcp --permanent
sudo firewall-cmd --add-port=514/tcp --permanent
sudo firewall-cmd --add-port=514/udp --permanent
sudo firewall-cmd --reload


#sed -i "s/^enabled=1/enabled=0/" /etc/yum.repos.d/wazuh.repo
#yum remove wazuh-agent

# Disable the Wazuh agent service and reload systemd manager configuration
#systemctl disable wazuh-agent
#systemctl daemon-reload
