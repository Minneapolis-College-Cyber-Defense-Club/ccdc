import os

port = input("Ingrese el puerto que desea asignar: ")

cmd = 'sed -i "s/^#*Port .*/Port {}/g" /etc/ssh/sshd_config'.format(port)

os.system(cmd)

cmd_restart = 'service ssh restart'
os.system(cmd_restart)

print("El puerto se ha cambiado correctamente y el servicio ssh se ha reiniciado.")
