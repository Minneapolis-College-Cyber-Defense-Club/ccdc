
#I have this script. 
tmux new-session -s mysession -n screen-1 -d \; \

split-window -h -p 50 -t 0 \; \
split-window -v -p 50 -t 1 \; \
select-pane -t 0 \; \
split-window -v -p 50 \; \
select-pane -t 2



#How I can add this to the scrip?
tmux attach-session -t mysession


