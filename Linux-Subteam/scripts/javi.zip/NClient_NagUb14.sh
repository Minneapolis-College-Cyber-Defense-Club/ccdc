#!/bin/bash

sudo apt-get install nagios-nrpe-server

#addhost
sudo nano /etc/nagios/nrpe.cfg


# Define the line to add to the end of the file
new_line="command[check_uptime]=/usr/local/nagios/libexec/check_uptime"

# Add the new line to the end of the file
echo "$new_line" | sudo tee -a n >/dev/null

sudo service nagios-nrpe-server restart
sudo service nagios-nrpe-server status

ip route
