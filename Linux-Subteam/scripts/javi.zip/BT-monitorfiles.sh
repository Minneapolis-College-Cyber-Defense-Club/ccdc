#!/bin/bash
#Monitor for new created files ever 5 mins

watch -n 300 -d ls -lR /
