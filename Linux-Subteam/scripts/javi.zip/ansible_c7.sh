#!/bin/bash
sudo yum update -y
sudo yum install epel-release -y
sudo yum install ansible -y
ansible --version

