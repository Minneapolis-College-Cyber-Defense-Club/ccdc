import shutil
import os

# Nombre de los archivos a copiar
archivo1 = "copyAns.yml"
archivo2 = "inv.py"

# Directorio de destino
destino = "/etc/ansible"

# Copiar archivos a destino
try:
    # Copiar archivo1
    shutil.copy(archivo1, destino)
    print(f"Archivo {archivo1} copiado a {destino}")
    
    # Copiar archivo2
    shutil.copy(archivo2, destino)
    print(f"Archivo {archivo2} copiado a {destino}")
    
except Exception as e:
    print("Ha ocurrido un error: ", e)


# Moverse a la carpeta
os.chdir(destino)

# Ejecutar el programa
os.system("python3 inv.py")

os.chdir(destino)


