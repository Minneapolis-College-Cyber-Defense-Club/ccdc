#!/bin/bash

# Update the package index
sudo apt update

# Install software-properties-common
sudo apt install software-properties-common

# Add the Ansible PPA and update the package index
sudo add-apt-repository --yes --update ppa:ansible/ansible

# Install Ansible
sudo apt install ansible


ansible --version
