
#!/bin/bash

tmux new-session -s user -n screen-1 -d \; \
split-window -h -p 50 -t 0 \; \
split-window -v -p 50 -t 1 \; \
select-pane -t 0 \; \
split-window -v -p 50 \; \
select-pane -t 2

tmux send-keys -t user:screen-1.0 "ubuntu14" C-m
tmux send-keys -t user:screen-1.1 "2012ad" C-m
tmux send-keys -t user:screen-1.2 "ubuntuwk" C-m
tmux send-keys -t user:screen-1.3 
