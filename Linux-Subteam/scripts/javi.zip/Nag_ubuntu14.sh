sudo dpkg -l selinux*
sudo apt update && sudo apt install -y php
sudo apt-get install -y autoconf 
sudo apt-get install -y gcc 
sudo apt-get install -y libc6
sudo apt-get install -y make
sudo apt-get install -y wget
sudo apt-get install -y unzip
sudo apt-get install -y apache2
sudo apt-get install -y apache2
sudo apt-get install -y-utils
sudo apt-get install -y php5
sudo apt-get install -y libgd2-xpm-dev 
sudo apt-get install -y libgd-dev

# Download and extract Nagios Core source code
cd /tmp
wget -O nagioscore.tar.gz https://github.com/NagiosEnterprises/nagioscore/archive/nagios-4.4.6.tar.gz
tar xzf nagioscore.tar.gz
cd /tmp/nagioscore-nagios-4.4.6/

# Configure and build Nagios Core
sudo ./configure --with-httpd-conf=/etc/apache2/sites-enabled
sudo make all
cd /tmp/nagioscore-nagios-4.4.6/
sudo make install-groups-users
sudo usermod -a -G nagios www-data
sudo make install
sudo make install-daemoninit
sudo make install-commandmode
sudo make install-config
sudo make install-webconf
sudo a2enmod rewrite
sudo a2enmod cgi
sudo ufw allow Apache
sudo ufw reload