tmux new-session -s mysession -n screen-1 -d \; \
  setw synchronize-panes on \; \
  split-window -h -p 50 -t 0 \; \
  split-window -v -p 50 -t 1 \; \
  select-pane -t 0 \; \
  split-window -v -p 50 \; \
  select-pane -t 2