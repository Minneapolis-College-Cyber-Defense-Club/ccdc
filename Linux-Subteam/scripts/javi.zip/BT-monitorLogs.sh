#!/bin/bash
#monitor logs in real time

less +F /var/log/messages

