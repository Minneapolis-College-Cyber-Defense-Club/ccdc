#!/bin/bash

sudo apt install nagios-nrpe-server -y

sudo nano /etc/nagios/nrpe.cfg

sudo systemctl restart nagios-nrpe-server

