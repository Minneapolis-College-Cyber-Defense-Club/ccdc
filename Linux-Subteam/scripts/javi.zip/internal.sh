
#!/bin/bash

tmux new-session -s internal -n screen-1 -d \; \
split-window -h -p 50 -t 0 \; \
split-window -v -p 50 -t 1 \; \
select-pane -t 0 \; \
split-window -v -p 50 \; \
select-pane -t 2

tmux send-keys -t internal:screen-1.0 "docker16" C-m
tmux send-keys -t internal:screen-1.1 "dnsMaria" C-m


