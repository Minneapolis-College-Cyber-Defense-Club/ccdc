import os
mensaje = '''\


                          
   mmm                  "   
     #   mmm   m   m  mmm   
     #  "   #  "m m"    #   
     #  m"""#   #m#     #   
 "mmm"  "mm"#    #    mm#mm 

This program follows the basic rules of open source code to make it more accessible
 and understandable for other developers. Even though I am currently only using it
  for internal testing, it's important to follow these rules to allow for future 
  developments and collaborations.

I want to apologize for not including comments in all scripts or using descriptive 
names for all variables and functions. I only had a three-week time frame to complete 
the project, but I understand the importance of these practices and will do our best
 to incorporate them in future versions of the program.

Thank you for your understanding and for your collaboration in
 creating a high-quality open source program.

Javi J*/
'''

print(mensaje)
# Obtiene la ruta del directorio actual
#ruta_actual = os.getcwd() #real
# Define la ruta de la carpeta que contiene los scripts como la ruta actual
#ruta_scripts = ruta_actual #real
ruta_scripts = '/home/dave2001/ccdc'
#ruta_scripts = '/home/admin/ccdc'
while True:
    # Obtener una lista de los scripts en la carpeta
    scripts = [archivo for archivo in os.listdir(ruta_scripts) if archivo.endswith(".sh")]

    # Mostrar al usuario los scripts disponibles
    print("Los siguientes scripts están disponibles para ejecutar:")
    for i in range(0, len(scripts), 3):
        script1 = f"{i+1}. {scripts[i]}" if i < len(scripts) else ""
        script2 = f"{i+2}. {scripts[i+1]}" if i+1 < len(scripts) else ""
        script3 = f"{i+3}. {scripts[i+2]}" if i+2 < len(scripts) else ""
        print("{:<30}{:<30}{:<}".format(script1, script2, script3))

    # Pedir al usuario que seleccione un script para ejecutar
    script_seleccionado = input("Ingrese el número del script que desea ejecutar (o 'q' para salir): ")

    # Salir del programa si el usuario ingresa 'q'
    if script_seleccionado == 'q':
        break

    # Verificar que el valor ingresado es un número entero válido
    if not script_seleccionado.isdigit() or int(script_seleccionado) < 1 or int(script_seleccionado) > len(scripts):
        print("Ingrese un número válido.")
        continue

    # Ejecutar el script seleccionado
    ruta_script = os.path.join(ruta_scripts, scripts[int(script_seleccionado)-1])
    os.system(f"bash {ruta_script}")

    # Mostrar un mensaje indicando que el script se ha ejecutado
    print(f"El script {scripts[int(script_seleccionado)-1]} se ha ejecutado correctamente.")

