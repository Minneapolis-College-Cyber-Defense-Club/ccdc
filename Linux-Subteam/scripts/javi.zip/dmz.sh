
#!/bin/bash

tmux new-session -s dmz -n screen-1 -d \; \
split-window -h -p 50 -t 0 \; \
split-window -v -p 50 -t 1 \; \
select-pane -t 0 \; \
split-window -v -p 50 \; \
select-pane -t 2

tmux send-keys -t dmz:screen-1.0 "2012" C-m
tmux send-keys -t dmz:screen-1.1 "dns" C-m
tmux send-keys -t dmz:screen-1.2 "ubuntu18" C-m
tmux send-keys -t dmz:screen-1.3 "ubuntu16" C-m

