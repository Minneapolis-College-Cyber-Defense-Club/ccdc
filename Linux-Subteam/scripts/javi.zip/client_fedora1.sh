

sudo yum install -y gcc glibc glibc-common openssl openssl-devel
cd ~
wget https://github.com/NagiosEnterprises/nrpe/releases/download/nrpe-4.1.0/nrpe-4.1.0.tar.gz
tar xzf nrpe-4.1.0.tar.gz
cd nrpe-4.1.0
sudo ./configure
sudo make all
sudo make install
sudo useradd nrpe
sudo groupadd nrpe
sudo usermod -a -G nrpe nrpe

sudo cp /usr/local/nagios/etc/nrpe.cfg-sample /usr/local/nagios/etc/nrpe.cfg
sudo nano /usr/local/nagios/etc/nrpe.cfg
sudo /usr/local/nagios/bin/nrpe -c /usr/local/nagios/etc/nrpe.cfg -d
sudo firewall-cmd --add-port=5666/tcp --permanent
sudo firewall-cmd --reload

