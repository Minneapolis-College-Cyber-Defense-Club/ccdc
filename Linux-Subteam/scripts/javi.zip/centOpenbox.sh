#!/bin/bash

sudo yum update -y
sudo yum install xorg-x11-server-Xorg -y
sudo yum install gdm -y
sudo yum groupinstall "GNOME Desktop" -
sudo systemctl enable gdm
sudo yum install openbox -y
sudo echo "exec openbox-session" > ~/.xinitrc
#sudo reboot
#startx
