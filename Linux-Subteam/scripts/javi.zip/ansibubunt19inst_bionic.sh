#!/bin/bash


# Add Ansible repository to /etc/apt/sources.list
echo "deb http://ppa.launchpad.net/ansible/ansible/ubuntu bionic main" | sudo tee -a /etc/apt/sources.list

# Import Ansible GPG key
sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys 93C4A3FD7BB9C367

# Update package lists
sudo apt update

# Install Ansible
sudo apt install ansible

ansible --version
