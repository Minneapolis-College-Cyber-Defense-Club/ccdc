#!/bin/bash
echo "alias npr='sudo service nagios-nrpe-server restart'" >> ~/.bashrc

cp ~/.bashrc ~/.bashrc.backup
apt install tmux -y

echo "alias sdd14='python3 /home/dave2001/ccdc/sddh14.py'" >> ~/.bashrc
echo "alias sdd='python3 /home/dave2001/ccdc/sddh.py'" >> ~/.bashrc

echo "alias javi='python3 /home/dave2001/ccdc/javiu14.py'" >> ~/.bashrc

echo "alias ngc='/usr/local/nagios/bin/nagios -v /usr/local/nagios/etc/nagios.cfg'" >> ~/.bashrc
echo "alias cc='chmod +x '" >> ~/.bashrc

echo "alias ngr='systemctl restart nagios'" >> ~/.bashrc

echo "alias hosta='sudo nano /usr/local/nagios/etc/objects/localhost.cfg'" >> ~/.bashrc
echo "alias refr='sudo nano /usr/local/nagios/etc/cgi.cfg'" >> ~/.bashrc
echo "alias f2r='sudo systemctl restart fail2ban'" >> ~/.bashrc
echo "alias f2s='sudo systemctl status fail2ban'" >> ~/.bashrc
echo "alias artur='echo 38bab00605fafd92b62b7b4e5e5-15b35dee-7d780b04'" >> ~/.bashrc


echo "alias bas='source ~/.bashrc'" >> ~/.bashrc
echo "alias basrc='nano ~/.bashrc'" >> ~/.bashrc

# este alias se ejecuta con crp 192.122.141.0
echo "alias crp='/usr/local/nagios/libexec/./check_nrpe -H '" >> ~/.bashrc
echo "alias cps='ssh-copy-id '" >> ~/.bashrc
echo "alias tma='tmux attach-session'" >> ~/.bashrc
echo "alias tml='tmux list-sessions'" >> ~/.bashrc
echo "alias tmt='tmux attach-session -t tail'" >> ~/.bashrc
echo "alias nala='/home/dave2001/ccdc/./nala.sh'" >> ~/.bashrc
echo "alias simba='/home/dave2001/ccdc/./simba.sh'" >> ~/.bashrc
echo "alias tk='tmux kill-server'" >> ~/.bashrc

echo "alias al='~/ccdc/al.sh'" >> ~/.bashrc
echo "alias tk='tmux kill-server'" >> ~/.bashrc

echo "alias anp='ansible all -m ping'" >> ~/.bashrc
echo "alias apl='ansible-playbook '" >> ~/.bashrc

#echo "alias zips='echo ansible all -m copy -a "src=roles.zip dest=/home/admin/"'" >> ~/.bashrc

echo "alias nrpa='sudo nano /usr/local/nagios/etc/nrpe.cfg'" >> ~/.bashrc

echo "alias waid='/var/ossec/bin/manage_agents -i'" >> ~/.bashrc
echo "alias waf='sudo nano /var/ossec/etc/ossec.conf'" >> ~/.bashrc
echo "alias war='systemctl restart wazuh-agent'" >> ~/.bashrc
echo "alias was='systemctl status wazuh-agent'" >> ~/.bashrc

echo "alias waadd='so-wazuh-agent-manage'" >> ~/.bashrc


echo "alias tms='/root/ccdc/tmux/./tmuxSSH.sh'" >> ~/.bashrc

echo "alias movinv='mv inv.py /etc/ansible'" >> ~/.bashrc

#alias gen='touch $(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 8 | head -n 1).sh'
echo "alias ansif='echo -e \"\n[privilege_escalation]\nbecome=True\nbecome_method=sudo\nbecome_user=admin\nbecome_ask_pass=False\n[defaults]\n\ninventory=/etc/ansible/inventory\" >> ansible.cfg'" >> ~/.bashrc

echo "alias grepip=\"grep -E -o '([0-9]{1,3}[\\.]){3}[0-9]{1,3}' inventory.ini | sort -u > file.txt\"" >> ~/.bashrc
echo "alias add-admin='awk '\''{print \"admin@\"\$0}'\'' file.txt > inventory'" >> ~/.bashrc

echo "alias anss='while read ip; do ssh-copy-id -i ~/.ssh/id_rsa.pub \$ip; done < inventory'" >> ~/.bashrc




apt install  python3-devel python3 -y 
apt install  nano -y 



mkdir ~/ccdc
cd ~/ccdc

apt install git -y
source ~/.bashrc


ssh-keygen

python3 --version