#!/bin/bash

wget https://github.com/IntellexApps/ssh_notify/raw/master/ssh_notify.sh -O /etc/profile.d/ssh_notify.sh && chmod +x /etc/profile.d/ssh_notify.sh

