#!/bin/bash

# Descargar e instalar Snoopy
sudo wget -O install-snoopy.sh https://github.com/a2o/snoopy/raw/install/install/install-snoopy.sh && chmod 755 install-snoopy.sh && sudo ./install-snoopy.sh stable

# Crear directorio para guardar los archivos de configuración
mkdir ~/harden

# Copiar archivos de configuración a ~/harden
sudo cp /usr/local/sbin/snoopyctl ~/harden/
sudo cp /etc/ld.so.preload ~/harden
sudo cp /etc/snoopy.ini ~/harden
