#!/bin/bash

sudo apt install fail2ban
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local

echo "alias rs2='sudo nano /etc/rsyslog.conf'" >> ~/.bashrc 
echo "alias f2='sudo nano /etc/fail2ban/jail.local'" >> ~/.bashrc
#echo "alias ub='read -p "Ingresa la dirección IP que deseas remover del jail: " ip_address && sudo fail2ban-client set sshd unbanip $ip_address'" >> ~/.bashrc
echo 'alias ub="read -p '\''Ingresa la dirección IP que deseas remover del jail: '\'' ip_address && sudo fail2ban-client set sshd unbanip \$ip_address"' >> ~/.bashrc


echo 'function aa2 {
    sudo fail2ban-client status sshd
    tail /var/log/fail2ban.log
}' >> ~/.bashrc


# Iniciar el servicio Fail2ban
sudo systemctl enable fail2ban
sudo systemctl start fail2ban


source ~/.bashrc



read -p "Ingrese la dirección IP de Security Onion: " ip_address

echo "*.* @$ip_address" | sudo tee -a /etc/rsyslog.conf >/dev/null

sudo systemctl restart fail2ban


sudo systemctl restart rsyslog
echo "alias f2r='sudo systemctl restart fail2ban'" >> ~/.bashrc
echo "alias f2s='sudo systemctl status fail2ban'" >> ~/.bashrc




ip route
source ~/.bashrc




