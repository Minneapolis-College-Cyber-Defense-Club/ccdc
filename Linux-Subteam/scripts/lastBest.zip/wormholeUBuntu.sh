#!/bin/bash

# Install required packages
sudo apt update
sudo apt install -y python3-pip python3-wheel python3-dev

# Install Wormhole
sudo apt install magic-wormhole
