
#!/bin/bash
sudo apt install ubuntu-desktop -y
sudo apt install xinit -y
sudo apt install gdm3 -y

sudo systemctl disable gdm3.service
sudo apt-get install openbox -y
sudo echo "exec openbox-session" > ~/.xinitrc

sudo apt install python3-xdg

sudo apt install x11-xserver-utils -y
sudo apt install firefox -y

sudo update-alternatives --config x-session-manager
