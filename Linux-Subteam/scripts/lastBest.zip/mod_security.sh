#!/bin/bash

yum install mod_security
#https://github.com/SpiderLabs/ModSecurity/blob/v3/master/modsecurity.conf-recommended

#Set Blocking Mode to ON

#https://www.trustwave.com/en-us/resources/blogs/spiderlabs-blog/web-application-defenders-cookbook-ccdc-blue-team-cheatsheet/

