#!/bin/bash
tail -f /var/log/messages | while read line
do
  echo $linedone