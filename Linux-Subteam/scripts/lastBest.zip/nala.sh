
tmux new-session -s mysession -n screen-1 -d \; \
split-window -h -p 50 -t 0 \; \
split-window -v -p 50 -t 1 \; \
select-pane -t 0 \; \
split-window -v -p 50 \; \
select-pane -t 2

tmux send-keys -t mysession:screen-1.0  
tmux send-keys -t mysession:screen-1.1  
tmux send-keys -t mysession:screen-1.2  
tmux send-keys -t mysession:screen-1.3 "echo hola" C-m

