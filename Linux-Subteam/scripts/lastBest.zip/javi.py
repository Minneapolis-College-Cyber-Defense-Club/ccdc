import os
mensaje = '''\


May contain


 m    m        ""#
 ##  ##  mmm     #   m     m  mmm    m mm   mmm
 # ## # "   #    #   "m m m" "   #   #"  " #"  #
 # "" # m"""#    #    #m#m#  m"""#   #     #""""
 #    # "mm"#    "mm   # #   "mm"#   #     "#mm"  Malware

Malware and backdoors alert! Be aware.

'''

print(mensaje)
# Obtiene la ruta del directorio actual
#ruta_actual = os.getcwd() #real
# Define la ruta de la carpeta que contiene los scripts como la ruta actual
#ruta_scripts = ruta_actual #real
#ruta_scripts = '/home/dave2001/ccdc'
ruta_scripts = '/home/admin/ccdc'
while True:
    # Obtener una lista de los scripts en la carpeta
    scripts = [archivo for archivo in os.listdir(ruta_scripts) if archivo.endswith(".sh")]

    # Mostrar al usuario los scripts disponibles
    print("Los siguientes scripts están disponibles para ejecutar:")
    for i in range(0, len(scripts), 3):
        script1 = f"{i+1}. {scripts[i]}" if i < len(scripts) else ""
        script2 = f"{i+2}. {scripts[i+1]}" if i+1 < len(scripts) else ""
        script3 = f"{i+3}. {scripts[i+2]}" if i+2 < len(scripts) else ""
        print("{:<30}{:<30}{:<}".format(script1, script2, script3))

    # Pedir al usuario que seleccione un script para ejecutar
    script_seleccionado = input("Ingrese el número del script que desea ejecutar (o 'q' para salir): ")

    # Salir del programa si el usuario ingresa 'q'
    if script_seleccionado == 'q':
        break

    # Verificar que el valor ingresado es un número entero válido
    if not script_seleccionado.isdigit() or int(script_seleccionado) < 1 or int(script_seleccionado) > len(scripts):
        print("Ingrese un número válido.")
        continue

    # Ejecutar el script seleccionado
    ruta_script = os.path.join(ruta_scripts, scripts[int(script_seleccionado)-1])
    os.system(f"bash {ruta_script}")

    # Mostrar un mensaje indicando que el script se ha ejecutado
    print(f"El script {scripts[int(script_seleccionado)-1]} se ha ejecutado correctamente.")

