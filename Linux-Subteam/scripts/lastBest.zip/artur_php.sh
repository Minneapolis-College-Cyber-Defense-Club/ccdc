#!/bin/bash

git clone https://github.com/phpmyadmin.git
