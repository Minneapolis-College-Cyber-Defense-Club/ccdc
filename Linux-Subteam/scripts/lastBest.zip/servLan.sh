
#!/bin/bash

tmux new-session -s serverLan -n screen-1 -d \; \
split-window -h -p 50 -t 0 \; \
split-window -v -p 50 -t 1 \; \
select-pane -t 0 \; \
split-window -v -p 50 \; \
select-pane -t 2

tmux send-keys -t serverLan:screen-1.0 "dnsLan" C-m
tmux send-keys -t serverLan:screen-1.1 "onion" C-m
tmux send-keys -t serverLan:screen-1.2 "ad" C-m
tmux send-keys -t serverLan:screen-1.3 

