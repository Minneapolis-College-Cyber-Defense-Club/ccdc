#!/bin/bash

#desabilitar rpcbind
sudo systemctl status rpcbind
sudo systemctl disable rpcbind
sudo systemctl stop rpcbind
sudo systemctl status rpcbind

#RPCBIND es un servicio utilizado para traducir los nombres de programas RPC (Remote #Procedure Call) a números de puerto. RPC es un protocolo utilizado por los sistemas Unix #y Linux para permitir que los programas se ejecuten en diferentes sistemas a través de la #red. Sin embargo, rpcbind puede ser un punto de entrada para ataques de seguridad y por #lo tanto es recomendable deshabilitarlo si no se necesita en el sistema.


