
#!/bin/bash

yum install nmap -y

awk -F '.' '{if ($1==ip1 && $2==ip2 && $3==ip3) printf(",%d",$4); else {if (NR>1) printf("\n"); printf("%s.%s.%s.%d", $1, $2, $3, $4); ip1=$1; ip2=$2; ip3=$3;}} END {printf("\n")}' ips.txt > resultado.txt

nmap -v --reason -sS -oX puertos.xml --stylesheet="https://svn.nmap.org/nmap/docs/nmap.xsl" $(cat resultado.txt)







#awk -F '.' '{if ($1==ip1 && $2==ip2 && $3==ip3) printf(",%d",$4); else {if (NR>1) printf("\n"); printf("%s.%s.%s.%d", $1, $2, $3, $4); ip1=$1; ip2=$2; ip3=$3;}} END {printf("\n")}' ips.txt > resultado.txt


#nmap -v --reason -sS -oX puertos.xml --stylesheet="https://svn.nmap.org/nmap/docs/nmap.xsl" cat(resultado.txt)

