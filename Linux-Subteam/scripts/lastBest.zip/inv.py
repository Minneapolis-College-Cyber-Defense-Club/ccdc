# Pide al usuario que ingrese las direcciones IP de los servidores y los grupos a los que pertenecen
servers = {}
while True:
    server_name = input("Ingrese el nombre del servidor (o 'fin' para terminar): ")
    if server_name == 'fin':
        break
    server_ip = input("Ingrese la dirección IP del servidor {}: ".format(server_name))
    server_group = input("Ingrese el nombre del grupo al que pertenece el servidor {}: ".format(server_name))
    if server_group not in servers:
        servers[server_group] = {}
    servers[server_group][server_name] = server_ip

# Agrega un grupo que contenga a todos los servidores
servers['all'] = {}
for server_group in servers:
    for server_name, server_ip in servers[server_group].items():
        servers['all'][server_name] = server_ip

# Crea el archivo de inventario
with open('inventory.ini', 'w') as f:
    for group_name, group_servers in servers.items():
        f.write('[{}]\n'.format(group_name))
        for server_name, server_ip in group_servers.items():
            f.write('{} ansible_host={}\n'.format(server_name, server_ip))
        f.write('\n')
