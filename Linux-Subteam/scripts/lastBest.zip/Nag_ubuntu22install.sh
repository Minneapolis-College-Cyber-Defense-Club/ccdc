#!/bin/bash

cp ~/.bashrc ~/.bashrc.backup


echo "alias ncc='/usr/local/nagios/bin/nagios -v /usr/local/nagios/etc/nagios.cfg'" >> ~/.bashrc
echo "alias nrr='systemctl restart nagios'" >> ~/.bashrc

echo "Lines added to ~/.bashrc"



sudo apt install wget unzip curl openssl build-essential libgd-dev libssl-dev libapache2-mod-php php-gd php apache2
wget https://assets.nagios.com/downloads/nagioscore/releases/nagios-4.4.6.tar.gz
sudo tar -zxvf nagios-4.4.6.tar.gz
cd nagios-4.4.6
./configure
make all
make install-groups-users
usermod -a -G nagios www-data
make install
make install-commandmode
make install-config
make install-webconf
a2enmod rewrite
a2enmod cgi
ufw allow apache
sudo ufw enable
ufw reload
sudo systemctl restart apache2
