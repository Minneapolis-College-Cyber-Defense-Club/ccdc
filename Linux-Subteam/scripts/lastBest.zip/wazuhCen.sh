#!/bin/bash

# Import Wazuh GPG key
rpm --import https://packages.wazuh.com/key/GPG-KEY-WAZUH

# Add Wazuh repository configuration
cat > /etc/yum.repos.d/wazuh.repo << EOF
[wazuh]
gpgcheck=1
gpgkey=https://packages.wazuh.com/key/GPG-KEY-WAZUH
enabled=1
name=EL-\$releasever - Wazuh
baseurl=https://packages.wazuh.com/4.x/yum/
protect=1
EOF


systemctl enable wazuh-agent.service

echo "alias wass='systemctl status wazuh-agent.service'" >> ~/.bashrc
echo "alias wasr='systemctl restart wazuh-agent.service'" >> ~/.bashrc 
echo "alias wast='tail -f /var/ossec/logs/ossec.log'" >> ~/.bashrc 
echo "alias wasf='sudo nano /var/ossec/etc/ossec.conf'" >> ~/.bashrc

sudo firewall-cmd --add-port=1514/tcp --permanent
sudo firewall-cmd --add-port=1514/udp --permanent
sudo firewall-cmd --add-port=1515/tcp --permanent
sudo firewall-cmd --add-port=514/tcp --permanent
sudo firewall-cmd --add-port=514/udp --permanent
sudo firewall-cmd --reload

# Install Wazuh agent and set the WAZUH_MANAGER variable to the manager IP address
WAZUH_MANAGER="10.0.0.2" yum install wazuh-agent -y

# Reload systemd manager configuration and start the Wazuh agent service
systemctl daemon-reload
systemctl enable wazuh-agent
systemctl start wazuh-agent

# Disable the Wazuh repository and remove the Wazuh agent package
#sed -i "s/^enabled=1/enabled=0/" /etc/yum.repos.d/wazuh.repo
#yum remove wazuh-agent

# Disable the Wazuh agent service and reload systemd manager configuration
#systemctl disable wazuh-agent
#systemctl daemon-reload
